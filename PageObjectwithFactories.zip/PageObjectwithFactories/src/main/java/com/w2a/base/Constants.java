package com.w2a.base;

public class Constants {
	
	
	//Configuration
	public static final String browser = "chrome";
	public static final String testsiteurl = "http://expedia.co.in";
	public static long implicitwait=10;
	
	
	//locators
	

}
